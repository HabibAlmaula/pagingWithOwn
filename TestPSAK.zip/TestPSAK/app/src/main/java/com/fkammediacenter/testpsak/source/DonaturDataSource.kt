package com.fkammediacenter.testpsak.source

import android.annotation.SuppressLint
import com.fkammediacenter.testpsak.base.BaseDataSource
import com.fkammediacenter.testpsak.daoResponse.DonaturKotakResponse
import com.fkammediacenter.testpsak.utils.api.BaseApiService
import com.fkammediacenter.testpsak.utils.api.UtilsApi
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class DonaturDataSource(var donatur: String,
                               var id_fr: String,
                               var nama : String) : BaseDataSource<DonaturKotakResponse>(){
    private val baseApiService : BaseApiService = UtilsApi.getAPIService()



    @SuppressLint("CheckResult")
    override fun loadInitialData(params: LoadInitialParams<Int>, callback: LoadInitialCallback<Int, DonaturKotakResponse>) {
        if (nama.isEmpty() || nama == ""){
            baseApiService.getAllDonaturKotak(donatur, id_fr, 0, params.requestedLoadSize)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(this::addDisposable)
                .subscribe(
                    { items -> submitInitialData(items, params, callback) },
                    { error -> submitInitialError(error) }
                )
        }else
          baseApiService.searchDonaturKotak(donatur,id_fr,nama,0, params.requestedLoadSize)
              .subscribeOn(Schedulers.io())
              .observeOn(AndroidSchedulers.mainThread())
              .doOnSubscribe(this::addDisposable)
              .subscribe(
                  { items -> submitInitialData(items, params, callback) },
                  { error -> submitInitialError(error) }
              )
    }

    @SuppressLint("CheckResult")
    override fun loadAditionalData(params: LoadParams<Int>, callback: LoadCallback<Int, DonaturKotakResponse>) {
        if (nama.isEmpty() || nama ==""){
            baseApiService.getAllDonaturKotak(donatur,id_fr,params.key, params.requestedLoadSize)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(this::addDisposable)
                .subscribe(
                    { items -> submitData(items, params, callback) },
                    { error -> submitError(error) }
                )
        }
    }

}
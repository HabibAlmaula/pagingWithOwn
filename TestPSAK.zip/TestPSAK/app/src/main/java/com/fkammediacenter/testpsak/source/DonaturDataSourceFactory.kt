package com.fkammediacenter.testpsak.source

import com.fkammediacenter.testpsak.base.OnDataSourceLoading
import com.fkammediacenter.testpsak.daoResponse.DonaturKotakResponse
import javax.sql.DataSource

class DonaturDataSourceFactory(var loading : OnDataSourceLoading,
                               var donatur: String?,
                               var id_fr: String?,
                               var nama : String? ): android.arch.paging.DataSource.Factory<Int, DonaturKotakResponse>(){

    lateinit var source: DonaturDataSource

    override fun create(): android.arch.paging.DataSource<Int, DonaturKotakResponse>? {
        if (::source.isInitialized && source!=null) source.invalidate()
        if (donatur !=null && id_fr != null && nama !=null){
            source = DonaturDataSource(donatur!!, id_fr!!, nama!!)
            source.onDataSourceLoading = loading
            return source
        }

        return null
    }


}